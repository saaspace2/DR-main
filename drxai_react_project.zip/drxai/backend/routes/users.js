// routes/users.js
const express  = require('express');
const router   = express.Router();
const supabase = require('../config/supabase');
const { requireAuth, requireRole } = require('../middleware/auth');

// GET /api/users — admin only
router.get('/', requireAuth, requireRole('admin'), async (req, res) => {
  if (!supabase) return res.json({ users: [], mode: 'local' });
  try {
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    res.json({ users: (data || []).filter(u => u.role !== 'admin') });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/users/patients — for doctor patient-select
router.get('/patients', requireAuth, requireRole('admin', 'doctor'), async (req, res) => {
  if (!supabase) return res.json({ patients: [], mode: 'local' });
  try {
    const { data, error } = await supabase.from('profiles').select('id,name,email').eq('role', 'patient').order('name');
    if (error) throw error;
    res.json({ patients: data || [] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/users — create user (admin only)
router.post('/', requireAuth, requireRole('admin'), async (req, res) => {
  const { name, email, password, role, phone, speciality } = req.body;
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'Name, email, password and role required.' });
  }
  if (!supabase) return res.status(400).json({ error: 'Supabase required for user creation.' });
  try {
    const { data: su, error: suErr } = await supabase.auth.signUp({ email, password });
    if (suErr) throw suErr;
    const uid = su.user?.id;
    if (uid) {
      await supabase.from('profiles').insert({ id: uid, name, email, role, phone: phone || null, speciality: speciality || null });
    }
    res.json({ message: `Account created for ${name}.` });
  } catch (e) {
    res.status(400).json({ error: e.message || 'Registration failed.' });
  }
});

// DELETE /api/users/:id — admin only
router.delete('/:id', requireAuth, requireRole('admin'), async (req, res) => {
  const { id } = req.params;
  if (!supabase) return res.status(400).json({ error: 'Supabase required.' });
  try {
    const { error } = await supabase.from('profiles').delete().eq('id', id);
    if (error) throw error;
    res.json({ message: 'User removed.' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
