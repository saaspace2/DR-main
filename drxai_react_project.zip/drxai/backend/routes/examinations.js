// routes/examinations.js
const express  = require('express');
const router   = express.Router();
const supabase = require('../config/supabase');
const { requireAuth, requireRole } = require('../middleware/auth');

// GET /api/examinations — admin gets all, doctor gets their own, patient gets theirs
router.get('/', requireAuth, async (req, res) => {
  if (!supabase) return res.json({ examinations: [], mode: 'local' });
  try {
    let query = supabase.from('examinations').select('*').order('created_at', { ascending: false });
    if (req.user.role === 'doctor')  query = query.eq('doctor_id', req.user.id);
    if (req.user.role === 'patient') query = query.eq('patient_id', req.user.id);
    const { data, error } = await query;
    if (error) throw error;
    res.json({ examinations: data || [] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/examinations/:id — single exam
router.get('/:id', requireAuth, async (req, res) => {
  if (!supabase) return res.json({ examination: null, mode: 'local' });
  try {
    const { data, error } = await supabase.from('examinations').select('*').eq('id', req.params.id).single();
    if (error) throw error;
    // Patients can only see their own
    if (req.user.role === 'patient' && data.patient_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    res.json({ examination: data });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/examinations — save exam (doctor/admin)
router.post('/', requireAuth, requireRole('admin', 'doctor'), async (req, res) => {
  const { stage, confidence, probs, notes, medications, image_data, patient_id } = req.body;
  if (stage === undefined || confidence === undefined) {
    return res.status(400).json({ error: 'Stage and confidence are required.' });
  }

  const exam = {
    id: 'ex_' + Date.now(),
    doctor_id: req.user.id,
    patient_id: patient_id || null,
    stage: Number(stage),
    confidence: Number(confidence),
    probs: typeof probs === 'string' ? probs : JSON.stringify(probs),
    notes: notes || null,
    medications: typeof medications === 'string' ? medications : JSON.stringify(medications || []),
    image_data: image_data || null,
    created_at: new Date().toISOString()
  };

  if (!supabase) return res.json({ examination: exam, mode: 'local' });

  try {
    const { data, error } = await supabase.from('examinations').insert(exam).select().single();
    if (error) throw error;
    res.status(201).json({ examination: data });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// DELETE /api/examinations/:id — admin or the doctor who created it
router.delete('/:id', requireAuth, requireRole('admin', 'doctor'), async (req, res) => {
  if (!supabase) return res.json({ message: 'Deleted (local mode).' });
  try {
    let query = supabase.from('examinations').delete().eq('id', req.params.id);
    if (req.user.role === 'doctor') query = query.eq('doctor_id', req.user.id);
    const { error } = await query;
    if (error) throw error;
    res.json({ message: 'Examination deleted.' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/examinations/stats/summary — admin dashboard stats
router.get('/stats/summary', requireAuth, requireRole('admin'), async (req, res) => {
  if (!supabase) return res.json({ stats: {}, mode: 'local' });
  try {
    const { data: exams } = await supabase.from('examinations').select('stage,confidence,created_at');
    const { data: users } = await supabase.from('profiles').select('role');
    const total    = exams?.length || 0;
    const critical = exams?.filter(e => e.stage >= 3).length || 0;
    const avgConf  = total ? Math.round(exams.reduce((a, e) => a + (e.confidence || 0), 0) / total) : 0;
    const doctors  = users?.filter(u => u.role === 'doctor').length || 0;
    const patients = users?.filter(u => u.role === 'patient').length || 0;
    res.json({ stats: { total, critical, avgConf, doctors, patients } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
