// routes/chat.js — proxies OpenRouter requests to keep API key server-side
const express = require('express');
const router  = express.Router();
const { requireAuth } = require('../middleware/auth');

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || '';
const OPENROUTER_URL     = 'https://openrouter.ai/api/v1/chat/completions';

const SNAMES = [
  'No Diabetic Retinopathy',
  'Mild Non-Proliferative DR',
  'Moderate Non-Proliferative DR',
  'Severe Non-Proliferative DR',
  'Proliferative Diabetic Retinopathy'
];

function buildSystemPrompt(role, diagnosisContext) {
  const rolePrompt = (role === 'doctor' || role === 'admin')
    ? 'You are speaking with a medical professional. Use clinical terminology and cite evidence-based guidelines.'
    : 'You are speaking with a patient. Use clear, compassionate, accessible language.';

  const dxPart = diagnosisContext
    ? `\n\nCurrent diagnosis: Stage ${diagnosisContext.stage} (${SNAMES[diagnosisContext.stage]}), confidence ${diagnosisContext.confidence}%.`
    : '';

  return `You are an expert AI medical consultant specialising in diabetic retinopathy in the DR-XAI platform.\n\n${rolePrompt}${dxPart}\n\nKeep responses 150–280 words. Never act as the sole clinical diagnostic tool.`;
}

function fallbackReply(q) {
  const ql = q.toLowerCase();
  if (ql.includes('stage 0') || ql.includes('no dr'))
    return 'Stage 0 means no diabetic retinopathy detected — excellent news! Maintain annual dilated eye exams, HbA1c < 7%, and blood pressure < 130/80.';
  if (ql.includes('stage 4') || ql.includes('proliferative'))
    return 'Proliferative DR (Stage 4) is the most advanced stage requiring urgent specialist care. Treatments include panretinal photocoagulation, intravitreal anti-VEGF injections, and possibly vitrectomy surgery.';
  if (ql.includes('treat'))
    return 'Treatment scales with severity. Stages 0–1: glycaemic & BP control. Stage 2: anti-VEGF if indicated. Stages 3–4: urgent PRP laser, anti-VEGF injections, or vitrectomy.';
  if (ql.includes('caus'))
    return 'DR results from chronic hyperglycaemia damaging retinal microvasculature, causing capillary leakage, ischaemia, and eventually abnormal new vessel growth (neovascularisation).';
  if (ql.includes('revers'))
    return 'Early stages (0–1) can improve with strict metabolic control. Structural damage in stages 2–4 is generally not reversible; treatment goals focus on halting progression and preserving vision.';
  return 'Diabetic retinopathy is a common diabetes complication affecting the eyes\' blood vessels. I can explain stages, treatments, or your scan context. What would you like to know?';
}

// POST /api/chat
router.post('/', requireAuth, async (req, res) => {
  const { messages, diagnosisContext, userRole } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'messages array required.' });
  }

  if (!OPENROUTER_API_KEY) {
    // Fallback: return a static response based on the last user message
    const lastMsg = messages.filter(m => m.role === 'user').at(-1)?.content || '';
    return res.json({ reply: fallbackReply(lastMsg) });
  }

  try {
    const systemPrompt = buildSystemPrompt(userRole || req.user?.role, diagnosisContext);
    const response = await fetch(OPENROUTER_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.FRONTEND_URL || 'http://localhost:3000',
        'X-Title': 'DR-XAI'
      },
      body: JSON.stringify({
        model: 'openrouter/free',
        messages: [{ role: 'system', content: systemPrompt }, ...messages],
        temperature: 0.3
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API ${response.status}: ${errText}`);
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || 'Unable to process.';
    res.json({ reply });
  } catch (err) {
    console.error('[Chat] Error:', err.message);
    const lastMsg = messages.filter(m => m.role === 'user').at(-1)?.content || '';
    res.json({ reply: fallbackReply(lastMsg) });
  }
});

module.exports = router;
