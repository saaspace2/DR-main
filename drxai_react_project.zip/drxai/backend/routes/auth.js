// routes/auth.js
const express  = require('express');
const router   = express.Router();
const supabase = require('../config/supabase');

const ADMIN_EMAIL    = process.env.ADMIN_EMAIL    || 'admin@drxai.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@12345';

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required.' });

  // ── Admin hard-coded login ──
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    if (!supabase) {
      return res.json({
        user: { id: 'admin-local', name: 'Administrator', email: ADMIN_EMAIL },
        role: 'admin',
        token: null,
        mode: 'local'
      });
    }
    try {
      let { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        // Try to create admin account
        const su = await supabase.auth.signUp({ email, password });
        if (su.error && !su.error.message.toLowerCase().includes('already')) throw su.error;
        const si2 = await supabase.auth.signInWithPassword({ email, password });
        if (si2.error) throw new Error('Email confirmation required. Disable it in Supabase → Auth → Config.');
        data = si2.data;
      }
      await supabase.from('profiles').upsert({
        id: data.user.id, name: 'Administrator', email: ADMIN_EMAIL, role: 'admin'
      });
      return res.json({
        user: { id: data.user.id, name: 'Administrator', email: ADMIN_EMAIL },
        role: 'admin',
        token: data.session?.access_token || null
      });
    } catch (e) {
      return res.status(400).json({ error: e.message || 'Admin login failed.' });
    }
  }

  // ── Regular user login ──
  if (!supabase) {
    return res.status(400).json({ error: 'No Supabase configured. Use admin login or enable Supabase.' });
  }
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).single();
    if (!profile) throw new Error('Profile not found. Contact administrator.');
    return res.json({
      user: { id: data.user.id, name: profile.name, email: profile.email },
      role: profile.role,
      token: data.session?.access_token || null
    });
  } catch (e) {
    return res.status(401).json({ error: e.message || 'Login failed.' });
  }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
  if (supabase) await supabase.auth.signOut();
  res.json({ message: 'Logged out.' });
});

// GET /api/auth/session — validate existing token
router.get('/session', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token || !supabase) return res.status(401).json({ error: 'No session.' });
  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (error || !user) return res.status(401).json({ error: 'Invalid session.' });
    const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();
    res.json({ user: { id: user.id, name: profile?.name, email: user.email }, role: profile?.role });
  } catch (e) {
    res.status(401).json({ error: 'Session check failed.' });
  }
});

module.exports = router;
