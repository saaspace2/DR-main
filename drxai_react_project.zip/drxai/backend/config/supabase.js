const { createClient } = require('@supabase/supabase-js');

const supabaseUrl  = process.env.SUPABASE_URL  || '';
const supabaseKey  = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY || '';

let supabase = null;

if (supabaseUrl && !supabaseUrl.includes('YOUR_') && supabaseKey && !supabaseKey.includes('YOUR_')) {
  supabase = createClient(supabaseUrl, supabaseKey);
  console.log('[Supabase] Connected ✓');
} else {
  console.warn('[Supabase] No valid credentials — running in LOCAL (localStorage) mode');
}

module.exports = supabase;
