// server.js — DR·XAI Express Backend
require('dotenv').config();

const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');

const authRoutes  = require('./routes/auth');
const userRoutes  = require('./routes/users');
const examRoutes  = require('./routes/examinations');
const chatRoutes  = require('./routes/chat');

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Security ────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

// ── Rate Limiting ───────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' }
});
const chatLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20,
  message: { error: 'Chat rate limit exceeded. Please wait.' }
});
app.use('/api/', limiter);
app.use('/api/chat', chatLimiter);

// ── Body Parsing ────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));   // allow base64 images
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Routes ──────────────────────────────────────────────────────
app.use('/api/auth',            authRoutes);
app.use('/api/users',           userRoutes);
app.use('/api/examinations',    examRoutes);
app.use('/api/chat',            chatRoutes);

// ── Health check ────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    supabase: !!process.env.SUPABASE_URL && !process.env.SUPABASE_URL.includes('YOUR_'),
    openrouter: !!process.env.OPENROUTER_API_KEY,
    timestamp: new Date().toISOString()
  });
});

// ── 404 ──────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Route not found.' }));

// ── Global Error Handler ────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── Start ───────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║      DR·XAI Backend  v1.0.0          ║`);
  console.log(`╚══════════════════════════════════════╝`);
  console.log(`  Server    : http://localhost:${PORT}`);
  console.log(`  Health    : http://localhost:${PORT}/api/health`);
  console.log(`  Mode      : ${process.env.NODE_ENV || 'development'}\n`);
});
