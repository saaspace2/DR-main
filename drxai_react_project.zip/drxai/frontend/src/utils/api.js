// utils/api.js — centralised API calls to the Express backend
const BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function getToken() {
  return localStorage.getItem('drxai_token') || null;
}

async function request(path, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ── Auth ────────────────────────────────────────────────────────
export const api = {
  auth: {
    login:   (email, password)   => request('/api/auth/login',   { method: 'POST', body: JSON.stringify({ email, password }) }),
    logout:  ()                  => request('/api/auth/logout',  { method: 'POST' }),
    session: ()                  => request('/api/auth/session'),
  },
  users: {
    list:       ()               => request('/api/users'),
    patients:   ()               => request('/api/users/patients'),
    create:     (body)           => request('/api/users',        { method: 'POST', body: JSON.stringify(body) }),
    remove:     (id)             => request(`/api/users/${id}`,  { method: 'DELETE' }),
  },
  examinations: {
    list:       ()               => request('/api/examinations'),
    get:        (id)             => request(`/api/examinations/${id}`),
    save:       (body)           => request('/api/examinations', { method: 'POST', body: JSON.stringify(body) }),
    remove:     (id)             => request(`/api/examinations/${id}`, { method: 'DELETE' }),
    stats:      ()               => request('/api/examinations/stats/summary'),
  },
  chat: {
    send: (messages, diagnosisContext, userRole) =>
      request('/api/chat', { method: 'POST', body: JSON.stringify({ messages, diagnosisContext, userRole }) }),
  },
  health: () => request('/api/health'),
};

export default api;
