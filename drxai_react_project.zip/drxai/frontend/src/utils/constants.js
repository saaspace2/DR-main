// utils/constants.js
export const SNAMES = [
  'No Diabetic Retinopathy',
  'Mild Non-Proliferative DR',
  'Moderate Non-Proliferative DR',
  'Severe Non-Proliferative DR',
  'Proliferative Diabetic Retinopathy'
];

export const SCOLS = ['#00ff88', '#00d4ff', '#ffcc00', '#ff6b35', '#ff2d55'];

export const RECS = [
  ['Annual dilated eye exam recommended', 'Maintain HbA1c < 7%', 'Monitor BP (<130/80 mmHg) and lipids', 'No direct ocular treatment required', 'Continue diabetes management plan'],
  ['Ophthalmic review every 9–12 months', 'Urgently optimise glycaemic control', 'Initiate antihypertensive therapy', 'Refer to diabetologist', 'Patient education on progression risks'],
  ['Ophthalmology review every 4–6 months', 'Urgent glycaemic & BP optimisation', 'Consider intravitreal anti-VEGF', 'Fluorescein angiography for mapping', 'Consider fenofibrate (FIELD trial evidence)'],
  ['Urgent vitreoretinal specialist referral', 'Panretinal photocoagulation (PRP) evaluation', 'Monthly ophthalmology follow-up', 'Intravitreal anti-VEGF likely required', 'Systemic risk factor control — critical'],
  ['EMERGENCY: Immediate vitreoretinal referral', 'Vitrectomy may be required', 'Urgent PRP laser therapy', 'High risk of severe vision loss — act now', 'Intensive multidisciplinary diabetes management']
];
