// App.js
import React, { useEffect } from 'react';
import './index.css';
import { AppProvider, useApp } from './context/AppContext';
import Navbar from './components/Navbar';
import { Toast } from './components/Toast';
import AuthPage from './pages/AuthPage';
import AdminPage from './pages/AdminPage';
import DoctorPage from './pages/DoctorPage';
import UploadPage from './pages/UploadPage';
import ResultsPage from './pages/ResultsPage';
import { PatientPage, ChatPage } from './pages/PatientPage';
import api from './utils/api';

function AppInner() {
  const { currentPage, currentUser, login, setCurrentPage } = useApp();

  // Restore session on mount
  useEffect(() => {
    const saved = localStorage.getItem('drxai_session');
    const token = localStorage.getItem('drxai_token');
    if (saved) {
      try {
        const s = JSON.parse(saved);
        if (s?.id && s?.role) {
          // Try to validate with backend
          if (token) {
            api.auth.session()
              .then(data => login(data.user, data.role, token))
              .catch(() => {
                // Fall back to local session
                login(s, s.role, null);
              });
          } else {
            login(s, s.role, null);
          }
        }
      } catch (_) {}
    }
  }, []);

  const pageMap = {
    auth:    <AuthPage />,
    admin:   <AdminPage />,
    doctor:  <DoctorPage />,
    upload:  <UploadPage />,
    results: <ResultsPage />,
    patient: <PatientPage />,
    chat:    <ChatPage />,
  };

  return (
    <>
      <Navbar />
      <div style={{ position: 'relative', zIndex: 1, animation: 'fadeIn 0.38s ease' }}>
        {pageMap[currentPage] || <AuthPage />}
      </div>
      <Toast />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}
