// pages/DoctorPage.js
import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { SNAMES, SCOLS } from '../utils/constants';
import api from '../utils/api';

export default function DoctorPage() {
  const { setCurrentPage, setLastProbs, setLastStage, setCurrentImg, showToast, currentUser } = useApp();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await api.examinations.list();
      setExams(data.examinations || []);
    } catch (e) {
      showToast('Error loading examinations.', 'err');
    }
    setLoading(false);
  }

  function viewExam(ex) {
    try { setLastProbs(JSON.parse(ex.probs || '[0,0,0,0,0]')); } catch { setLastProbs([0,0,0,0,0]); }
    setLastStage(Number(ex.stage));
    setCurrentImg(ex.image_data || null);
    setCurrentPage('results');
  }

  const total = exams.length;
  const critical = exams.filter(e => e.stage >= 3).length;
  const avgConf = total ? Math.round(exams.reduce((a,e) => a+(e.confidence||0), 0)/total) : 0;

  return (
    <div className="wrap">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div className="page-title" style={{ marginBottom: 0 }}>DOCTOR DASHBOARD</div>
        <button className="btn" onClick={() => setCurrentPage('upload')}>+ NEW SCAN</button>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, marginBottom: 24 }}>
        {[
          ['TOTAL SCANS', total, 'var(--accent)'],
          ['CRITICAL CASES', critical, 'var(--danger)'],
          ['AVG CONFIDENCE', `${avgConf}%`, 'var(--warn)'],
        ].map(([label, val, col]) => (
          <div key={label} className="card card-accent" style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '1.8rem', fontWeight: 900, color: col }}>{val}</div>
            <div style={{ fontSize: '0.63rem', color: 'var(--dim)', letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: 4 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Examinations */}
      <div className="card">
        <div className="section-title">MY EXAMINATIONS</div>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><div className="spinner" /></div>
        ) : exams.length === 0 ? (
          <div className="empty-state">
            No examinations yet. <span style={{ color: 'var(--accent)', cursor: 'pointer' }} onClick={() => setCurrentPage('upload')}>Start a new scan →</span>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="dt">
              <thead>
                <tr>
                  <th>Stage</th><th>Confidence</th><th>Notes</th><th>Medications</th><th>Date</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {exams.map(ex => {
                  let meds = [];
                  try { meds = JSON.parse(ex.medications || '[]'); } catch {}
                  return (
                    <tr key={ex.id}>
                      <td>
                        <span className={`sb s${ex.stage}`}>STAGE {ex.stage}</span>
                        <div style={{ fontSize: '0.72rem', color: 'var(--dim)', marginTop: 3 }}>{SNAMES[ex.stage]}</div>
                      </td>
                      <td style={{ fontFamily: 'Orbitron,monospace', color: SCOLS[ex.stage] }}>{ex.confidence}%</td>
                      <td style={{ fontSize: '0.8rem', color: 'var(--dim)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ex.notes || '—'}</td>
                      <td style={{ fontSize: '0.78rem' }}>
                        {meds.length > 0 ? meds.slice(0,2).map((m,i) => (
                          <span key={i} style={{ display: 'inline-block', padding: '2px 7px', background: 'rgba(0,212,255,0.07)', border: '1px solid rgba(0,212,255,0.2)', color: 'var(--accent)', fontSize: '0.7rem', marginRight: 4, marginBottom: 2 }}>{m}</span>
                        )) : <span style={{ color: 'var(--dim)' }}>—</span>}
                        {meds.length > 2 && <span style={{ color: 'var(--dim)', fontSize: '0.7rem' }}>+{meds.length-2} more</span>}
                      </td>
                      <td style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.72rem', color: 'var(--dim)' }}>{new Date(ex.created_at).toLocaleDateString('en-IN')}</td>
                      <td><button className="btn btn-sm" onClick={() => viewExam(ex)}>VIEW</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
