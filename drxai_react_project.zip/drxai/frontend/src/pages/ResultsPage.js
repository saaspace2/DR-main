// pages/ResultsPage.js
import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { SNAMES, SCOLS, RECS } from '../utils/constants';
import api from '../utils/api';

export default function ResultsPage() {
  const { lastProbs, lastStage, currentImg, currentUser, currentRole, setCurrentPage, showToast } = useApp();
  const [notes, setNotes]           = useState('');
  const [medications, setMedications] = useState([]);
  const [medInput, setMedInput]     = useState('');
  const [patients, setPatients]     = useState([]);
  const [patientId, setPatientId]   = useState('');
  const [saving, setSaving]         = useState(false);
  const canvasRef = useRef();

  useEffect(() => {
    if (currentRole !== 'patient') {
      api.users.patients().then(d => setPatients(d.patients || [])).catch(() => {});
    }
  }, [currentRole]);

  useEffect(() => {
    if (lastProbs && canvasRef.current) drawSpeedometer(canvasRef.current, lastStage, lastProbs[lastStage]);
  }, [lastProbs, lastStage]);

  if (!lastProbs) {
    return (
      <div className="wrap">
        <div className="page-title">ANALYSIS RESULTS</div>
        <div className="card card-accent">
          <div className="empty-state">No analysis results yet. Please upload and analyse a fundus image first.</div>
          <div className="btn-row">
            <button className="btn" onClick={() => setCurrentPage('upload')}>← GO TO SCAN</button>
          </div>
        </div>
      </div>
    );
  }

  const stage    = lastStage;
  const prob     = lastProbs[stage];
  const stageCol = SCOLS[stage];

  const addMed = () => {
    if (medInput.trim()) { setMedications(m => [...m, medInput.trim()]); setMedInput(''); }
  };

  const saveExam = async () => {
    setSaving(true);
    try {
      await api.examinations.save({
        stage, confidence: Math.round(prob * 100),
        probs: JSON.stringify(lastProbs), notes,
        medications: JSON.stringify(medications),
        image_data: currentImg, patient_id: patientId || null
      });
      showToast('Examination saved ✓', 'ok');
      setCurrentPage(currentRole === 'admin' ? 'admin' : 'doctor');
    } catch (e) {
      showToast('Save failed: ' + e.message, 'err');
    }
    setSaving(false);
  };

  return (
    <div className="wrap">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div className="page-title" style={{ marginBottom: 0 }}>ANALYSIS RESULTS</div>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <button className="btn btn-sm" onClick={() => setCurrentPage(currentRole === 'admin' ? 'admin' : 'doctor')}>← BACK</button>
          <button className="btn btn-sm btn-o" onClick={() => setCurrentPage('chat')}>AI CONSULT →</button>
          <button className="btn btn-sm btn-g" onClick={saveExam} disabled={saving}>{saving ? '…' : '💾 SAVE'}</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 22, alignItems: 'start' }}>
        {/* Left column */}
        <div>
          {/* Diagnosis card */}
          <div className="card" style={{ borderLeft: `4px solid ${stageCol}` }}>
            <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.6rem', color: 'var(--accent)', letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: 11 }}>◈ PRIMARY DIAGNOSIS</div>
            <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '1.9rem', fontWeight: 900, color: stageCol, marginBottom: 3 }}>STAGE {stage}</div>
            <div style={{ fontSize: '0.9rem', color: 'var(--dim)', marginBottom: 11 }}>{SNAMES[stage]}</div>
            <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '2.6rem', fontWeight: 900, color: 'var(--accent)', textShadow: 'var(--glow)' }}>{Math.round(prob * 100)}%</div>
            <div style={{ fontSize: '0.63rem', color: 'var(--dim)', letterSpacing: '0.15em', textTransform: 'uppercase', marginTop: 3 }}>CONFIDENCE SCORE</div>
          </div>

          {/* Image */}
          {currentImg && (
            <div className="card">
              <div className="section-title">FUNDUS IMAGE</div>
              <img src={currentImg} alt="fundus" style={{ width: '100%', maxHeight: 210, objectFit: 'contain', display: 'block' }} />
              <div style={{ marginTop: 12, position: 'relative' }}>
                <div className="section-title">XAI ATTENTION MAP</div>
                <div style={{ position: 'relative', display: 'inline-block', width: '100%' }}>
                  <img src={currentImg} alt="xai" style={{ width: '100%', maxHeight: 200, objectFit: 'contain', display: 'block' }} />
                  <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 58% 38% at 55% 52%,rgba(255,50,50,.52) 0%,rgba(255,165,0,.32) 28%,rgba(255,255,0,.15) 58%,transparent 78%)', mixBlendMode: 'screen', pointerEvents: 'none' }} />
                </div>
                <div style={{ display: 'flex', gap: 13, marginTop: 9, justifyContent: 'center', fontSize: '0.69rem', color: 'var(--dim)' }}>
                  {[['rgba(255,50,50,.8)', 'High'], ['rgba(255,165,0,.7)', 'Medium'], ['rgba(255,255,0,.6)', 'Low']].map(([c,l]) => (
                    <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                      <div style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />{l}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right column */}
        <div>
          {/* Speedometer */}
          <div className="card">
            <div className="section-title">SEVERITY GAUGE</div>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
              <canvas ref={canvasRef} width={310} height={200} />
            </div>
          </div>

          {/* Probability bars */}
          <div className="card">
            <div className="section-title">PROBABILITY DISTRIBUTION</div>
            {lastProbs.map((p, i) => (
              <div key={i} style={{ marginBottom: 15 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: '0.79rem', fontWeight: 600, color: i === stage ? 'var(--text)' : 'var(--dim)' }}>
                    Stage {i} — {SNAMES[i].split('—')[1]?.trim() || SNAMES[i]}
                    {i === stage && <span style={{ display: 'inline-block', background: 'var(--accent)', color: 'var(--bg)', fontFamily: 'Orbitron,monospace', fontSize: '0.46rem', fontWeight: 900, padding: '2px 5px', letterSpacing: '0.08em', marginLeft: 6, verticalAlign: 'middle' }}>MAX</span>}
                  </span>
                  <span style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.79rem', fontWeight: 700, color: SCOLS[i] }}>{Math.round(p * 100)}%</span>
                </div>
                <div style={{ height: 4, background: 'rgba(255,255,255,0.05)', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${Math.round(p*100)}%`, background: SCOLS[i], transition: 'width 1.4s cubic-bezier(0.22,1,0.36,1)' }} />
                </div>
              </div>
            ))}
          </div>

          {/* Recommendations */}
          <div className="card">
            <div className="section-title">CLINICAL RECOMMENDATIONS</div>
            <ul style={{ listStyle: 'none' }}>
              {RECS[stage].map((r, i) => (
                <li key={i} style={{ padding: '7px 0', borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: '0.87rem', fontWeight: 300, lineHeight: 1.6, display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                  <span style={{ color: 'var(--accent)', flexShrink: 0, marginTop: 2 }}>▸</span>{r}
                </li>
              ))}
            </ul>
          </div>

          {/* Patient select */}
          {currentRole !== 'patient' && patients.length > 0 && (
            <div className="card">
              <div className="section-title">LINK TO PATIENT</div>
              <select className="field-input" value={patientId} onChange={e => setPatientId(e.target.value)} style={{ marginBottom: 0 }}>
                <option value="">— Select patient (optional) —</option>
                {patients.map(p => <option key={p.id} value={p.id}>{p.name} ({p.email})</option>)}
              </select>
            </div>
          )}

          {/* Notes & Medications */}
          {currentRole !== 'patient' && (
            <div className="card">
              <div className="section-title">DOCTOR'S NOTES</div>
              <textarea
                value={notes} onChange={e => setNotes(e.target.value)}
                placeholder="Clinical observations, follow-up instructions…"
                style={{ width: '100%', background: 'var(--sf2)', border: '1px solid rgba(0,212,255,0.18)', color: 'var(--text)', fontFamily: 'Rajdhani,sans-serif', fontSize: '0.88rem', padding: '11px 13px', resize: 'vertical', minHeight: 90, outline: 'none', marginBottom: 16 }}
              />
              <div className="section-title">PRESCRIBED MEDICATIONS</div>
              {medications.map((m, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 11px', background: 'rgba(0,212,255,0.04)', border: '1px solid rgba(0,212,255,0.11)', marginBottom: 6 }}>
                  <span style={{ fontSize: '0.86rem' }}>{m}</span>
                  <button onClick={() => setMedications(meds => meds.filter((_,j) => j !== i))} style={{ background: 'transparent', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '0.78rem', padding: '2px 6px' }}>✕</button>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  value={medInput} onChange={e => setMedInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addMed()}
                  placeholder="Medication name / dosage…"
                  style={{ flex: 1, padding: '9px 12px', background: 'var(--sf2)', border: '1px solid rgba(0,212,255,0.18)', color: 'var(--text)', fontFamily: 'Rajdhani,sans-serif', fontSize: '0.86rem', outline: 'none' }}
                />
                <button onClick={addMed} style={{ padding: '9px 15px', background: 'transparent', border: '1px solid var(--accent)', color: 'var(--accent)', fontFamily: 'Orbitron,monospace', fontSize: '0.62rem', cursor: 'pointer', letterSpacing: '0.1em' }}>+ ADD</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function drawSpeedometer(canvas, stage, confidence) {
  const ctx  = canvas.getContext('2d');
  const W    = canvas.width, H = canvas.height;
  const cx   = W / 2, cy = H * 0.78;
  const r    = Math.min(W, H) * 0.56;
  const SCOLS = ['#00ff88','#00d4ff','#ffcc00','#ff6b35','#ff2d55'];
  const SNAMES = ['No DR','Mild NPDR','Moderate NPDR','Severe NPDR','Proliferative DR'];
  ctx.clearRect(0, 0, W, H);
  const arc = (s, e, color, lw=14) => {
    ctx.beginPath();
    ctx.arc(cx, cy, r, s, e);
    ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.lineCap = 'round';
    ctx.stroke();
  };
  const start = Math.PI, end = 2 * Math.PI;
  arc(start, end, 'rgba(255,255,255,0.05)', 16);
  const seg = (end - start) / 5;
  for (let i = 0; i < 5; i++) arc(start + i * seg + 0.04, start + (i + 1) * seg - 0.04, SCOLS[i], 12);

  // Needle
  const angle = start + (stage + confidence) / 5 * (end - start);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.moveTo(-8, 0); ctx.lineTo(r * 0.85, 0);
  ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
  ctx.stroke();
  ctx.restore();

  // Center dot
  ctx.beginPath(); ctx.arc(cx, cy, 7, 0, Math.PI * 2);
  ctx.fillStyle = '#fff'; ctx.fill();

  // Label
  ctx.fillStyle = SCOLS[stage];
  ctx.font = `bold 13px Orbitron, monospace`;
  ctx.textAlign = 'center';
  ctx.fillText(`STAGE ${stage}`, cx, cy - r * 0.3);
  ctx.fillStyle = 'rgba(200,220,240,0.7)';
  ctx.font = `10px Share Tech Mono, monospace`;
  ctx.fillText(SNAMES[stage].toUpperCase(), cx, cy - r * 0.18);
}
