// pages/AdminPage.js
import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { SNAMES, SCOLS } from '../utils/constants';
import api from '../utils/api';
import { ConfirmModal } from '../components/Toast';

export default function AdminPage() {
  const { showToast, setCurrentPage, setLastProbs, setLastStage, setCurrentImg } = useApp();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats,  setStats]  = useState({});
  const [users,  setUsers]  = useState([]);
  const [exams,  setExams]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [confirm, setConfirm] = useState(null);

  // Register form state
  const [regRole, setRegRole]   = useState('doctor');
  const [regName, setRegName]   = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPwd, setRegPwd]     = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regSpec, setRegSpec]   = useState('');
  const [regMsg, setRegMsg]     = useState({ type: '', text: '' });
  const [regLoading, setRegLoading] = useState(false);

  useEffect(() => { loadAll(); }, []);

  async function loadAll() {
    setLoading(true);
    try {
      const [e, u] = await Promise.all([api.examinations.list(), api.users.list()]);
      setExams(e.examinations || []);
      setUsers(u.users || []);
      const total = (e.examinations || []).length;
      const critical = (e.examinations || []).filter(x => x.stage >= 3).length;
      const avgConf = total ? Math.round((e.examinations || []).reduce((a,x) => a+(x.confidence||0), 0)/total) : 0;
      const doctors = (u.users || []).filter(x => x.role === 'doctor').length;
      const patients = (u.users || []).filter(x => x.role === 'patient').length;
      setStats({ total, critical, avgConf, doctors, patients });
    } catch (err) {
      showToast('Load error: ' + err.message, 'err');
    }
    setLoading(false);
  }

  async function handleRegister(e) {
    e.preventDefault();
    setRegMsg({ type: '', text: '' });
    if (!regName || !regEmail || !regPwd) { setRegMsg({ type: 'err', text: 'Name, email and password required.' }); return; }
    if (regPwd.length < 8) { setRegMsg({ type: 'err', text: 'Password must be ≥ 8 characters.' }); return; }
    setRegLoading(true);
    try {
      await api.users.create({ name: regName, email: regEmail, password: regPwd, role: regRole, phone: regPhone, speciality: regSpec });
      setRegMsg({ type: 'ok', text: `✓ ${regRole} account created for ${regName}` });
      setRegName(''); setRegEmail(''); setRegPwd(''); setRegPhone(''); setRegSpec('');
      loadAll();
    } catch (err) {
      setRegMsg({ type: 'err', text: err.message || 'Registration failed.' });
    }
    setRegLoading(false);
  }

  function removeUser(id, name) {
    setConfirm({ title: 'Remove User', message: `Remove "${name}"? This cannot be undone.`, onConfirm: async () => {
      try { await api.users.remove(id); showToast(`Removed: ${name}`, 'ok'); loadAll(); }
      catch (e) { showToast('Remove failed: ' + e.message, 'err'); }
      setConfirm(null);
    }});
  }

  function viewExam(exam) {
    setLastProbs(JSON.parse(exam.probs || '[0,0,0,0,0]'));
    setLastStage(Number(exam.stage));
    setCurrentImg(exam.image_data || null);
    setCurrentPage('results');
  }

  const tabs = ['overview', 'register', 'users', 'exams'];

  return (
    <div className="wrap">
      {confirm && <ConfirmModal {...confirm} onCancel={() => setConfirm(null)} />}
      <div className="page-title">ADMIN CONTROL CENTRE</div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 22 }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setActiveTab(t)} style={{
            padding: '10px 20px', background: 'transparent', border: 'none',
            borderBottom: activeTab === t ? '2px solid var(--purple)' : '2px solid transparent',
            color: activeTab === t ? 'var(--purple)' : 'var(--dim)',
            fontFamily: 'Orbitron,monospace', fontSize: '0.66rem', letterSpacing: '0.1em',
            cursor: 'pointer', transition: 'all 0.2s', marginBottom: -1, textTransform: 'uppercase'
          }}>{t}</button>
        ))}
      </div>

      {loading && <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><div className="spinner" /></div>}

      {/* Overview */}
      {!loading && activeTab === 'overview' && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 14, marginBottom: 24 }}>
            {[
              ['TOTAL SCANS', stats.total || 0, 'var(--accent)'],
              ['CRITICAL', stats.critical || 0, 'var(--danger)'],
              ['AVG CONFIDENCE', `${stats.avgConf || 0}%`, 'var(--warn)'],
              ['DOCTORS', stats.doctors || 0, 'var(--a2)'],
              ['PATIENTS', stats.patients || 0, 'var(--ok)'],
            ].map(([label, val, col]) => (
              <div key={label} className="card card-accent" style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '1.8rem', fontWeight: 900, color: col }}>{val}</div>
                <div style={{ fontSize: '0.63rem', color: 'var(--dim)', letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: 4 }}>{label}</div>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="section-title">RECENT EXAMINATIONS</div>
            {exams.length === 0 ? <div className="empty-state">No examinations yet.</div> : (
              <div style={{ overflowX: 'auto' }}>
                <table className="dt">
                  <thead><tr><th>Stage</th><th>Confidence</th><th>Date</th><th>Actions</th></tr></thead>
                  <tbody>
                    {exams.slice(0, 5).map(ex => (
                      <tr key={ex.id}>
                        <td><span className={`sb s${ex.stage}`}>STAGE {ex.stage}</span></td>
                        <td style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.78rem', color: SCOLS[ex.stage] }}>{ex.confidence}%</td>
                        <td style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.72rem', color: 'var(--dim)' }}>{new Date(ex.created_at).toLocaleDateString()}</td>
                        <td><button className="btn btn-sm" onClick={() => viewExam(ex)}>VIEW</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* Register */}
      {activeTab === 'register' && (
        <div className="card card-accent" style={{ maxWidth: 560 }}>
          <div className="section-title">CREATE USER ACCOUNT</div>
          {regMsg.text && (
            <div style={{
              padding: '9px 12px', marginBottom: 14, fontSize: '0.82rem',
              color: regMsg.type === 'ok' ? 'var(--ok)' : 'var(--danger)',
              background: regMsg.type === 'ok' ? 'rgba(0,255,136,0.07)' : 'rgba(255,45,85,0.09)',
              border: `1px solid ${regMsg.type === 'ok' ? 'rgba(0,255,136,0.3)' : 'rgba(255,45,85,0.35)'}`
            }}>{regMsg.text}</div>
          )}
          <form onSubmit={handleRegister}>
            <div style={{ display: 'flex', gap: 10, marginBottom: 13 }}>
              {['doctor', 'patient'].map(r => (
                <button key={r} type="button" onClick={() => setRegRole(r)} style={{
                  flex: 1, padding: 10, background: 'transparent',
                  border: `1px solid ${regRole === r ? (r === 'doctor' ? 'var(--a2)' : 'var(--ok)') : 'var(--border)'}`,
                  color: regRole === r ? (r === 'doctor' ? 'var(--a2)' : 'var(--ok)') : 'var(--dim)',
                  fontFamily: 'Orbitron,monospace', fontSize: '0.6rem', cursor: 'pointer'
                }}>{r.toUpperCase()}</button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
              <div style={{ gridColumn: '1/-1' }}>
                <label className="field-label">FULL NAME</label>
                <input className="field-input" value={regName} onChange={e => setRegName(e.target.value)} placeholder="Dr. John Smith" />
              </div>
              <div>
                <label className="field-label">EMAIL</label>
                <input className="field-input" type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} placeholder="user@hospital.com" />
              </div>
              <div>
                <label className="field-label">PASSWORD</label>
                <input className="field-input" type="password" value={regPwd} onChange={e => setRegPwd(e.target.value)} placeholder="≥ 8 chars" />
              </div>
              <div>
                <label className="field-label">PHONE</label>
                <input className="field-input" value={regPhone} onChange={e => setRegPhone(e.target.value)} placeholder="+91 98765 43210" />
              </div>
              <div>
                <label className="field-label">SPECIALITY</label>
                <input className="field-input" value={regSpec} onChange={e => setRegSpec(e.target.value)} placeholder="Ophthalmologist" />
              </div>
            </div>
            <button type="submit" className="btn" disabled={regLoading} style={{ width: '100%', justifyContent: 'center', padding: 13, fontSize: '0.78rem', marginTop: 5 }}>
              {regLoading ? 'CREATING…' : 'CREATE ACCOUNT'}
            </button>
          </form>
        </div>
      )}

      {/* Users table */}
      {activeTab === 'users' && (
        <div className="card">
          <div className="section-title">REGISTERED USERS</div>
          {users.length === 0 ? <div className="empty-state">No users registered yet.</div> : (
            <div style={{ overflowX: 'auto' }}>
              <table className="dt">
                <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Phone</th><th>Speciality</th><th>Actions</th></tr></thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id}>
                      <td style={{ fontWeight: 600 }}>{u.name || '—'}</td>
                      <td style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.78rem', color: 'var(--dim)' }}>{u.email}</td>
                      <td><span style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.5rem', border: '1px solid', padding: '2px 8px', color: u.role==='doctor' ? 'var(--a2)' : 'var(--ok)', borderColor: u.role==='doctor' ? 'rgba(255,107,53,0.4)' : 'rgba(0,255,136,0.4)' }}>{u.role?.toUpperCase()}</span></td>
                      <td style={{ color: 'var(--dim)', fontSize: '0.82rem' }}>{u.phone || '—'}</td>
                      <td style={{ color: 'var(--dim)', fontSize: '0.82rem' }}>{u.speciality || '—'}</td>
                      <td><button className="btn btn-sm btn-d" onClick={() => removeUser(u.id, u.name)}>REMOVE</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Exams table */}
      {activeTab === 'exams' && (
        <div className="card">
          <div className="section-title">ALL EXAMINATIONS</div>
          {exams.length === 0 ? <div className="empty-state">No examinations yet.</div> : (
            <div style={{ overflowX: 'auto' }}>
              <table className="dt">
                <thead><tr><th>Image</th><th>Stage</th><th>Confidence</th><th>Notes</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                  {exams.map(ex => (
                    <tr key={ex.id}>
                      <td>
                        {ex.image_data
                          ? <img src={ex.image_data} alt="" style={{ width: 52, height: 52, objectFit: 'cover', border: '1px solid var(--border)', cursor: 'pointer' }} onClick={() => viewExam(ex)} />
                          : <div style={{ width: 52, height: 52, background: 'var(--sf2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.44rem', color: 'var(--dim)', fontFamily: 'Share Tech Mono,monospace', textAlign: 'center' }}>NO IMG</div>
                        }
                      </td>
                      <td><span className={`sb s${ex.stage}`}>STAGE {ex.stage}</span></td>
                      <td style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.78rem', color: SCOLS[ex.stage] }}>{ex.confidence}%</td>
                      <td style={{ fontSize: '0.8rem', color: 'var(--dim)', maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ex.notes || '—'}</td>
                      <td style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.72rem', color: 'var(--dim)' }}>{new Date(ex.created_at).toLocaleDateString()}</td>
                      <td><button className="btn btn-sm" onClick={() => viewExam(ex)}>VIEW</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
