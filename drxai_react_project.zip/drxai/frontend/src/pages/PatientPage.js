// pages/PatientPage.js
import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { SNAMES, SCOLS } from '../utils/constants';
import api from '../utils/api';

export function PatientPage() {
  const { currentUser, showToast } = useApp();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.examinations.list()
      .then(d => setExams(d.examinations || []))
      .catch(() => showToast('Error loading results.', 'err'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="wrap" style={{ maxWidth: 920 }}>
      <div className="page-title">MY EXAMINATION RESULTS</div>
      <div style={{ color: 'var(--dim)', fontSize: '0.88rem', marginBottom: 26 }}>
        {currentUser?.name ? `Welcome, ${currentUser.name}` : 'Your diabetic retinopathy examination history'}
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><div className="spinner" /></div>
      ) : exams.length === 0 ? (
        <div className="card card-accent">
          <div className="empty-state">No examinations on record yet. Please ask your doctor to run a retinal scan.</div>
        </div>
      ) : (
        exams.map(ex => {
          let meds = [];
          try { meds = JSON.parse(ex.medications || '[]'); } catch {}
          const col = SCOLS[ex.stage];
          return (
            <div key={ex.id} className="card" style={{ borderTop: '2px solid', borderTopColor: col, position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg,transparent,${col},transparent)` }} />
              <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.62rem', color: 'var(--dim)', letterSpacing: '0.2em', marginBottom: 11 }}>
                {new Date(ex.created_at).toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}
              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
                <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '1.8rem', fontWeight: 900, color: col }}>
                  STAGE {ex.stage}
                </div>
                <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '1rem', color: 'var(--dim)' }}>
                  {ex.confidence}% confidence
                </div>
                <span className={`sb s${ex.stage}`}>{SNAMES[ex.stage]}</span>
              </div>
              {meds.length > 0 && (
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.6rem', color: 'var(--accent)', letterSpacing: '0.2em', marginBottom: 7 }}>PRESCRIBED MEDICATIONS</div>
                  {meds.map((m, i) => (
                    <span key={i} style={{ display: 'inline-block', padding: '3px 11px', background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.24)', color: 'var(--accent)', fontSize: '0.76rem', margin: '3px 3px 3px 0' }}>{m}</span>
                  ))}
                </div>
              )}
              {ex.notes && (
                <div style={{ background: 'rgba(0,212,255,0.04)', borderLeft: '3px solid var(--accent)', padding: '11px 15px', fontSize: '0.86rem', lineHeight: 1.7, color: 'var(--dim)', fontStyle: 'italic', marginTop: 11 }}>
                  "{ex.notes}"
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

// ── Chat Page ──────────────────────────────────────────────────
import { useRef } from 'react';

export function ChatPage() {
  const { currentRole, lastProbs, lastStage, showToast } = useApp();
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hello! I\'m the DR-XAI medical assistant. I can answer questions about diabetic retinopathy, diagnoses, and treatment options. Your scan results are automatically included in my context when available.' }
  ]);
  const [input, setInput]     = useState('');
  const [loading, setLoading] = useState(false);
  const boxRef = useRef();

  const QUICK = ['What is diabetic retinopathy?', 'Explain my diagnosis', 'What causes DR progression?', 'What are the treatments?', 'Is DR reversible?'];

  const send = async (text) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput('');
    const newMsgs = [...messages, { role: 'user', content: msg }];
    setMessages(newMsgs);
    setLoading(true);
    setTimeout(() => boxRef.current && (boxRef.current.scrollTop = 99999), 50);
    try {
      const diagCtx = lastProbs ? { stage: lastStage, confidence: Math.round(lastProbs[lastStage]*100) } : null;
      const apiMsgs = newMsgs.filter(m => m.role !== 'assistant' || messages.indexOf(m) > 0).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }));
      const data    = await api.chat.send(apiMsgs, diagCtx, currentRole);
      setMessages(m => [...m, { role: 'assistant', content: data.reply }]);
    } catch (e) {
      setMessages(m => [...m, { role: 'assistant', content: 'I\'m unable to connect right now. Please check your network or API configuration.' }]);
    }
    setLoading(false);
    setTimeout(() => boxRef.current && (boxRef.current.scrollTop = 99999), 100);
  };

  return (
    <div className="wrap">
      <div className="page-title">AI CONSULTATION</div>
      <div style={{ color: 'var(--dim)', fontSize: '0.86rem', marginBottom: 18 }}>Medical knowledge assistant · Powered by OpenRouter</div>

      <div style={{ maxWidth: 860, margin: '0 auto', display: 'flex', flexDirection: 'column' }}>
        {/* Quick suggestions */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
          {QUICK.map(q => (
            <button key={q} onClick={() => send(q)} style={{
              padding: '7px 14px', background: 'transparent', border: '1px solid rgba(0,212,255,0.22)',
              color: 'var(--dim)', fontFamily: 'Rajdhani,sans-serif', fontSize: '0.82rem', cursor: 'pointer',
              transition: 'all 0.2s'
            }}
            onMouseOver={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)'; }}
            onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(0,212,255,0.22)'; e.currentTarget.style.color = 'var(--dim)'; }}
            >{q}</button>
          ))}
        </div>

        {/* Message box */}
        <div ref={boxRef} style={{
          flex: 1, minHeight: 400, maxHeight: 450, overflowY: 'auto',
          border: '1px solid var(--border)', background: 'var(--surface)',
          padding: 20, marginBottom: 12, scrollBehavior: 'smooth'
        }}>
          {messages.map((m, i) => (
            <div key={i} style={{ marginBottom: 15, display: 'flex', gap: 10, flexDirection: m.role === 'user' ? 'row-reverse' : 'row', animation: 'fadeIn 0.28s ease' }}>
              <div style={{
                width: 31, height: 31, border: '1px solid',
                borderColor: m.role === 'assistant' ? 'rgba(0,212,255,0.4)' : 'rgba(255,107,53,0.4)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'Orbitron,monospace', fontSize: '0.56rem', fontWeight: 700, flexShrink: 0,
                background: 'var(--sf2)',
                color: m.role === 'assistant' ? 'var(--accent)' : 'var(--a2)'
              }}>{m.role === 'assistant' ? 'AI' : 'YOU'}</div>
              <div>
                <div style={{
                  background: m.role === 'assistant' ? 'var(--sf2)' : 'var(--sf3)',
                  border: `1px solid ${m.role === 'assistant' ? 'rgba(0,212,255,0.15)' : 'rgba(255,107,53,0.15)'}`,
                  padding: '12px 16px', fontSize: '0.88rem', lineHeight: 1.65,
                  maxWidth: 520,
                  dangerouslySetInnerHTML: { __html: m.content.replace(/\n/g,'<br>').replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>') }
                }} />
                <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.6rem', color: 'var(--dim)', marginTop: 4 }}>
                  {m.role === 'assistant' ? 'DR-XAI' : 'You'} · {new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}
                </div>
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: 'flex', gap: 10, marginBottom: 15 }}>
              <div style={{ width: 31, height: 31, border: '1px solid rgba(0,212,255,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Orbitron,monospace', fontSize: '0.56rem', color: 'var(--accent)', background: 'var(--sf2)' }}>AI</div>
              <div style={{ display: 'flex', gap: 5, alignItems: 'center', padding: '12px 16px', background: 'var(--sf2)', border: '1px solid rgba(0,212,255,0.15)' }}>
                {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', animation: `blink 1.2s ${i*0.2}s infinite` }} />)}
                <span style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.68rem', color: 'var(--dim)', marginLeft: 5 }}>Thinking…</span>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div style={{ display: 'flex', gap: 10 }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
            placeholder="Ask about diagnosis, treatment, prognosis…"
            style={{
              flex: 1, padding: '13px 16px', background: 'var(--sf2)',
              border: '1px solid rgba(0,212,255,0.2)', color: 'var(--text)',
              fontFamily: 'Rajdhani,sans-serif', fontSize: '0.92rem', outline: 'none'
            }}
          />
          <button onClick={() => send()} disabled={loading} className="btn" style={{ padding: '13px 22px', fontSize: '0.72rem' }}>
            SEND
          </button>
        </div>
      </div>
    </div>
  );
}
