// pages/AuthPage.js
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import api from '../utils/api';

export default function AuthPage() {
  const { login, showToast } = useApp();
  const [tab, setTab]       = useState('login');
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState('');

  // Login state
  const [email, setEmail]   = useState('');
  const [pwd, setPwd]       = useState('');

  // Register state
  const [regRole, setRegRole]   = useState('doctor');
  const [regName, setRegName]   = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPwd, setRegPwd]     = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regSpec, setRegSpec]   = useState('');
  const [regOk, setRegOk]       = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setErr('');
    if (!email || !pwd) { setErr('Please enter email and password.'); return; }
    setLoading(true);
    try {
      const data = await api.auth.login(email, pwd);
      login(data.user, data.role, data.token);
      showToast(`Welcome, ${data.user.name || data.user.email}!`, 'ok');
    } catch (err) {
      setErr(err.message || 'Login failed.');
    }
    setLoading(false);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setErr(''); setRegOk('');
    if (!regName || !regEmail || !regPwd) { setErr('Name, email and password required.'); return; }
    if (regPwd.length < 8) { setErr('Password must be ≥ 8 characters.'); return; }
    setLoading(true);
    try {
      await api.users.create({ name: regName, email: regEmail, password: regPwd, role: regRole, phone: regPhone, speciality: regSpec });
      setRegOk(`✓ ${regRole} account created for ${regName}. They can now log in.`);
      setRegName(''); setRegEmail(''); setRegPwd(''); setRegPhone(''); setRegSpec('');
    } catch (err) {
      setErr(err.message || 'Registration failed.');
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', position: 'relative', zIndex: 1 }}>
      <div style={{ width: '100%', maxWidth: 420 }}>
        {/* Hero */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ width: 72, height: 72, margin: '0 auto 14px', animation: 'pulse 3s ease-in-out infinite' }}>
            <svg viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ filter: 'drop-shadow(0 0 18px rgba(0,212,255,0.5))' }}>
              <ellipse cx="36" cy="36" rx="34" ry="20" stroke="#00d4ff" strokeWidth="2"/>
              <circle cx="36" cy="36" r="10" fill="none" stroke="#00d4ff" strokeWidth="1.5"/>
              <circle cx="36" cy="36" r="4" fill="#00d4ff"/>
              <circle cx="41" cy="31" r="2" fill="rgba(0,212,255,0.5)"/>
              <line x1="2" y1="36" x2="12" y2="36" stroke="#00d4ff" strokeWidth="1.5"/>
              <line x1="60" y1="36" x2="70" y2="36" stroke="#00d4ff" strokeWidth="1.5"/>
            </svg>
          </div>
          <div style={{ fontFamily: 'Orbitron,monospace', fontWeight: 900, fontSize: '1.9rem', color: 'var(--accent)', textShadow: 'var(--glow)' }}>DR·XAI</div>
          <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.62rem', color: 'var(--dim)', letterSpacing: '0.28em', marginTop: 4 }}>DIABETIC RETINOPATHY PLATFORM</div>
        </div>

        {/* Card */}
        <div style={{ border: '1px solid var(--border)', background: 'var(--surface)', padding: 30, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg,transparent,var(--accent),transparent)' }} />

          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 22 }}>
            {['login', 'register'].map(t => (
              <button key={t} onClick={() => { setTab(t); setErr(''); setRegOk(''); }}
                style={{
                  flex: 1, padding: '9px 0', background: 'transparent', border: 'none',
                  borderBottom: tab === t ? '2px solid var(--accent)' : '2px solid transparent',
                  color: tab === t ? 'var(--accent)' : 'var(--dim)',
                  fontFamily: 'Orbitron,monospace', fontSize: '0.62rem', letterSpacing: '0.1em',
                  cursor: 'pointer', transition: 'all 0.2s', marginBottom: -1
                }}
              >{t === 'login' ? 'SIGN IN' : 'REGISTER'}</button>
            ))}
          </div>

          {/* Error / OK messages */}
          {err && <div style={{ background: 'rgba(255,45,85,0.09)', border: '1px solid rgba(255,45,85,0.35)', color: 'var(--danger)', fontSize: '0.8rem', padding: '9px 12px', marginBottom: 14 }}>{err}</div>}
          {regOk && <div style={{ background: 'rgba(0,255,136,0.07)', border: '1px solid rgba(0,255,136,0.3)', color: 'var(--ok)', fontSize: '0.8rem', padding: '9px 12px', marginBottom: 14 }}>{regOk}</div>}

          {tab === 'login' ? (
            <form onSubmit={handleLogin}>
              <label className="field-label">EMAIL ADDRESS</label>
              <input className="field-input" type="email" placeholder="user@drxai.com" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
              <label className="field-label">PASSWORD</label>
              <input className="field-input" type="password" placeholder="••••••••" value={pwd} onChange={e => setPwd(e.target.value)} autoComplete="current-password" />
              <button type="submit" disabled={loading} style={{
                width: '100%', padding: 13, background: 'transparent', border: '2px solid var(--accent)',
                color: 'var(--accent)', fontFamily: 'Orbitron,monospace', fontSize: '0.78rem', fontWeight: 700,
                letterSpacing: '0.18em', cursor: 'pointer', transition: 'all 0.3s', marginTop: 5,
                opacity: loading ? 0.6 : 1
              }}>
                {loading ? 'SIGNING IN…' : 'SIGN IN'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister}>
              <div style={{ display: 'flex', gap: 10, marginBottom: 13 }}>
                {['doctor', 'patient'].map(r => (
                  <button key={r} type="button" onClick={() => setRegRole(r)} style={{
                    flex: 1, padding: 10, background: 'transparent',
                    border: `1px solid ${regRole === r ? (r === 'doctor' ? 'var(--a2)' : 'var(--ok)') : 'var(--border)'}`,
                    color: regRole === r ? (r === 'doctor' ? 'var(--a2)' : 'var(--ok)') : 'var(--dim)',
                    fontFamily: 'Orbitron,monospace', fontSize: '0.6rem', cursor: 'pointer', transition: 'all 0.2s'
                  }}>{r.toUpperCase()}</button>
                ))}
              </div>
              <label className="field-label">FULL NAME</label>
              <input className="field-input" placeholder="Dr. Jane Smith" value={regName} onChange={e => setRegName(e.target.value)} />
              <label className="field-label">EMAIL ADDRESS</label>
              <input className="field-input" type="email" placeholder="user@hospital.com" value={regEmail} onChange={e => setRegEmail(e.target.value)} />
              <label className="field-label">PASSWORD (MIN 8 CHARS)</label>
              <input className="field-input" type="password" placeholder="••••••••" value={regPwd} onChange={e => setRegPwd(e.target.value)} />
              {regRole === 'doctor' && <>
                <label className="field-label">PHONE (OPTIONAL)</label>
                <input className="field-input" placeholder="+91 98765 43210" value={regPhone} onChange={e => setRegPhone(e.target.value)} />
                <label className="field-label">SPECIALITY (OPTIONAL)</label>
                <input className="field-input" placeholder="Ophthalmologist" value={regSpec} onChange={e => setRegSpec(e.target.value)} />
              </>}
              <button type="submit" disabled={loading} style={{
                width: '100%', padding: 13, background: 'transparent', border: '2px solid var(--accent)',
                color: 'var(--accent)', fontFamily: 'Orbitron,monospace', fontSize: '0.78rem', fontWeight: 700,
                letterSpacing: '0.18em', cursor: 'pointer', transition: 'all 0.3s', marginTop: 5,
                opacity: loading ? 0.6 : 1
              }}>
                {loading ? 'CREATING…' : 'CREATE ACCOUNT'}
              </button>
            </form>
          )}

          <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.62rem', color: 'var(--dim)', textAlign: 'center', marginTop: 16, lineHeight: 1.8 }}>
            Admin: admin@drxai.com / Admin@12345
          </div>
        </div>
      </div>
    </div>
  );
}
