// pages/UploadPage.js
import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { SNAMES, SCOLS, RECS } from '../utils/constants';
import api from '../utils/api';

export default function UploadPage() {
  const { setLastProbs, setLastStage, setCurrentImg, setCurrentPage, showToast, currentUser } = useApp();
  const [dragOver, setDragOver] = useState(false);
  const [imgSrc, setImgSrc]     = useState(null);
  const [fileName, setFileName] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const fileRef = useRef();

  function handleFile(file) {
    if (!file || !file.type.startsWith('image/')) { showToast('Please select an image file.', 'err'); return; }
    const reader = new FileReader();
    reader.onload = e => { setImgSrc(e.target.result); setFileName(file.name); };
    reader.readAsDataURL(file);
  }

  function onDrop(e) {
    e.preventDefault(); setDragOver(false);
    handleFile(e.dataTransfer.files[0]);
  }

  async function analyze() {
    if (!imgSrc) return;
    setAnalyzing(true);
    showToast('Analysing retinal image…', 'info');

    try {
      // Try real ONNX model if available in public/
      let probs;
      if (window.ort) {
        try {
          const session = await window.ort.InferenceSession.create('/model/dr_model.onnx');
          const img = new Image();
          img.src = imgSrc;
          await new Promise(r => { img.onload = r; });
          const canvas = document.createElement('canvas');
          canvas.width = 224; canvas.height = 224;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, 224, 224);
          const imageData = ctx.getImageData(0, 0, 224, 224);
          const float32 = new Float32Array(3 * 224 * 224);
          for (let i = 0; i < 224 * 224; i++) {
            float32[i]              = (imageData.data[i*4]   / 255 - 0.485) / 0.229;
            float32[i + 224*224]    = (imageData.data[i*4+1] / 255 - 0.456) / 0.224;
            float32[i + 224*224*2]  = (imageData.data[i*4+2] / 255 - 0.406) / 0.225;
          }
          const tensor = new window.ort.Tensor('float32', float32, [1,3,224,224]);
          const feeds  = { input: tensor };
          const out    = await session.run(feeds);
          const logits = Object.values(out)[0].data;
          const maxL   = Math.max(...logits);
          const exp    = logits.map(v => Math.exp(v - maxL));
          const sum    = exp.reduce((a,b) => a+b, 0);
          probs        = exp.map(v => v / sum);
        } catch (_) {
          probs = simulatedInference();
        }
      } else {
        probs = simulatedInference();
      }

      const stage = probs.indexOf(Math.max(...probs));
      setLastProbs(probs);
      setLastStage(stage);
      setCurrentImg(imgSrc);
      showToast('Analysis complete ✓', 'ok');
      setCurrentPage('results');
    } catch (err) {
      showToast('Analysis failed: ' + err.message, 'err');
    }
    setAnalyzing(false);
  }

  return (
    <div className="wrap" style={{ maxWidth: 760 }}>
      <div className="page-title">NEW RETINAL SCAN</div>

      {/* Drop zone */}
      <div
        className={`upload-zone ${dragOver ? 'dov' : ''}`}
        style={{
          border: `2px dashed ${dragOver ? 'var(--accent)' : 'rgba(0,212,255,0.32)'}`,
          background: 'var(--surface)', padding: '58px 36px', cursor: 'pointer',
          transition: 'all 0.3s', textAlign: 'center', marginBottom: 18,
          boxShadow: dragOver ? 'var(--glow)' : 'none'
        }}
        onClick={() => fileRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
      >
        <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.92rem', color: 'var(--text)', marginBottom: 6 }}>
          DROP FUNDUS IMAGE HERE
        </div>
        <div style={{ fontSize: '0.83rem', color: 'var(--dim)' }}>or click to browse — JPG, PNG, WebP</div>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
      </div>

      {/* Preview */}
      {imgSrc && (
        <div style={{ maxWidth: 340, margin: '0 auto 18px', border: '1px solid var(--border)', padding: 9, background: 'var(--surface)' }}>
          <img src={imgSrc} alt="preview" style={{ width: '100%', maxHeight: 240, objectFit: 'contain', display: 'block' }} />
          <div style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.7rem', color: 'var(--accent)', marginTop: 5, textAlign: 'center' }}>{fileName}</div>
        </div>
      )}

      {/* Analyse button */}
      {imgSrc && (
        <button
          onClick={analyze}
          disabled={analyzing}
          style={{
            display: 'block', width: '100%', padding: 15,
            background: analyzing ? 'rgba(0,212,255,0.05)' : 'linear-gradient(135deg,rgba(0,212,255,0.12),rgba(0,212,255,0.04))',
            border: '2px solid var(--accent)', color: 'var(--accent)',
            fontFamily: 'Orbitron,monospace', fontSize: '0.88rem', fontWeight: 700,
            letterSpacing: '0.18em', cursor: analyzing ? 'not-allowed' : 'pointer',
            transition: 'all 0.3s', opacity: analyzing ? 0.7 : 1
          }}
        >
          {analyzing ? '⟳ ANALYSING…' : '⚡ ANALYSE RETINAL IMAGE'}
        </button>
      )}
    </div>
  );
}

// Deterministic-looking fake inference for demo (no model file needed)
function simulatedInference() {
  const raw = [Math.random()*2, Math.random()*1.5, Math.random()*1.2, Math.random()*0.9, Math.random()*0.6];
  const max  = Math.max(...raw);
  const exp  = raw.map(v => Math.exp(v - max));
  const sum  = exp.reduce((a,b) => a+b, 0);
  return exp.map(v => v / sum);
}
