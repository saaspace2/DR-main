// components/Navbar.js
import React from 'react';
import { useApp } from '../context/AppContext';
import api from '../utils/api';

export default function Navbar() {
  const { currentUser, currentRole, setCurrentPage, logout, showToast } = useApp();

  if (!currentUser) return null;

  const nav = (page) => setCurrentPage(page);

  const handleLogout = async () => {
    try { await api.auth.logout(); } catch (_) {}
    logout();
    showToast('Signed out.', 'info');
  };

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      padding: '12px 36px', display: 'flex', alignItems: 'center',
      justifyContent: 'space-between',
      background: 'rgba(2,11,24,0.95)', backdropFilter: 'blur(20px)',
      borderBottom: '1px solid var(--border)'
    }}>
      {/* Logo */}
      <div
        onClick={() => nav(currentRole === 'admin' ? 'admin' : currentRole === 'doctor' ? 'doctor' : 'patient')}
        style={{ fontFamily: 'Orbitron,monospace', fontWeight: 900, fontSize: '0.95rem', color: 'var(--accent)', letterSpacing: '0.15em', textShadow: 'var(--glow)', cursor: 'pointer' }}
      >
        DR·<span style={{ color: 'var(--a2)' }}>XAI</span>
      </div>

      {/* Links */}
      <ul style={{ display: 'flex', gap: 20, listStyle: 'none', alignItems: 'center' }}>
        {currentRole === 'admin' && <>
          <NavLink onClick={() => nav('admin')}>Dashboard</NavLink>
          <NavLink onClick={() => nav('chat')}>AI Consult</NavLink>
        </>}
        {currentRole === 'doctor' && <>
          <NavLink onClick={() => nav('doctor')}>Dashboard</NavLink>
          <NavLink onClick={() => nav('upload')}>New Scan</NavLink>
          <NavLink onClick={() => nav('chat')}>AI Consult</NavLink>
        </>}
        {currentRole === 'patient' && <>
          <NavLink onClick={() => nav('patient')}>My Results</NavLink>
          <NavLink onClick={() => nav('chat')}>AI Consult</NavLink>
        </>}
      </ul>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <span style={{
          fontFamily: 'Orbitron,monospace', fontSize: '0.52rem', padding: '3px 9px', border: '1px solid',
          color: currentRole === 'admin' ? 'var(--purple)' : currentRole === 'doctor' ? 'var(--a2)' : 'var(--ok)',
          borderColor: currentRole === 'admin' ? 'rgba(176,106,255,0.5)' : currentRole === 'doctor' ? 'rgba(255,107,53,0.5)' : 'rgba(0,255,136,0.5)'
        }}>{currentRole?.toUpperCase()}</span>
        <span style={{ fontFamily: 'Share Tech Mono,monospace', fontSize: '0.68rem', color: 'var(--dim)' }}>
          {currentUser.name || currentUser.email}
        </span>
        <button
          onClick={handleLogout}
          style={{
            background: 'transparent', border: '1px solid rgba(255,45,85,0.35)', color: 'var(--danger)',
            fontFamily: 'Orbitron,monospace', fontSize: '0.58rem', padding: '5px 11px', cursor: 'pointer',
            letterSpacing: '0.1em', transition: 'all 0.2s'
          }}
          onMouseOver={e => e.currentTarget.style.borderColor = 'var(--danger)'}
          onMouseOut={e => e.currentTarget.style.borderColor = 'rgba(255,45,85,0.35)'}
        >SIGN OUT</button>
      </div>
    </nav>
  );
}

function NavLink({ onClick, children }) {
  return (
    <li>
      <span
        onClick={onClick}
        style={{
          color: 'var(--dim)', textDecoration: 'none', fontSize: '0.76rem',
          fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase',
          transition: 'color 0.2s', cursor: 'pointer'
        }}
        onMouseOver={e => e.currentTarget.style.color = 'var(--accent)'}
        onMouseOut={e => e.currentTarget.style.color = 'var(--dim)'}
      >{children}</span>
    </li>
  );
}
