// components/Toast.js
import React from 'react';
import { useApp } from '../context/AppContext';

export function Toast() {
  const { toast } = useApp();
  const cls = toast.type === 'ok' ? 'toast-ok' : toast.type === 'err' ? 'toast-err' : 'toast-info';
  return (
    <div className={`toast ${cls} ${toast.show ? 'show' : ''}`}>
      {toast.msg}
    </div>
  );
}

// components/ConfirmModal.js
export function ConfirmModal({ title, message, onConfirm, onCancel }) {
  if (!title) return null;
  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div style={{ fontFamily: 'Orbitron,monospace', fontSize: '0.76rem', letterSpacing: '0.2em', color: 'var(--danger)', marginBottom: 12 }}>
          ⚠ {title}
        </div>
        <div style={{ fontSize: '0.88rem', color: 'var(--dim)', lineHeight: 1.6, marginBottom: 22 }}>{message}</div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button className="btn btn-sm" onClick={onCancel}>CANCEL</button>
          <button className="btn btn-sm btn-d" onClick={onConfirm}>CONFIRM</button>
        </div>
      </div>
    </div>
  );
}
