// context/AppContext.js
import React, { createContext, useContext, useState, useCallback } from 'react';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser]   = useState(null);
  const [currentRole, setCurrentRole]   = useState(null);
  const [currentPage, setCurrentPage]   = useState('auth');
  const [lastProbs,   setLastProbs]     = useState(null);
  const [lastStage,   setLastStage]     = useState(null);
  const [currentImg,  setCurrentImg]    = useState(null);
  const [toast,       setToastState]    = useState({ msg: '', type: 'info', show: false });

  const showToast = useCallback((msg, type = 'info') => {
    setToastState({ msg, type, show: true });
    setTimeout(() => setToastState(s => ({ ...s, show: false })), 3400);
  }, []);

  const login = useCallback((user, role, token) => {
    setCurrentUser(user);
    setCurrentRole(role);
    if (token) localStorage.setItem('drxai_token', token);
    localStorage.setItem('drxai_session', JSON.stringify({ ...user, role }));
    setCurrentPage(role === 'admin' ? 'admin' : role === 'doctor' ? 'doctor' : 'patient');
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setCurrentRole(null);
    setCurrentPage('auth');
    setLastProbs(null);
    setLastStage(null);
    setCurrentImg(null);
    localStorage.removeItem('drxai_token');
    localStorage.removeItem('drxai_session');
  }, []);

  return (
    <AppContext.Provider value={{
      currentUser, currentRole, currentPage, setCurrentPage,
      lastProbs, setLastProbs,
      lastStage, setLastStage,
      currentImg, setCurrentImg,
      toast, showToast,
      login, logout,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
