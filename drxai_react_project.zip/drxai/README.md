# DR·XAI — Diabetic Retinopathy AI Platform

A full-stack React + Node.js application for AI-powered diabetic retinopathy diagnosis,
with role-based access for Admins, Doctors, and Patients.

---

## 📁 Project Structure

```
drxai/
├── backend/                  ← Express.js API server
│   ├── config/
│   │   └── supabase.js       ← Supabase client initialisation
│   ├── middleware/
│   │   └── auth.js           ← JWT authentication guard
│   ├── routes/
│   │   ├── auth.js           ← Login / logout / session
│   │   ├── users.js          ← User CRUD (admin only)
│   │   ├── examinations.js   ← Exam CRUD with role filtering
│   │   └── chat.js           ← OpenRouter AI proxy
│   ├── server.js             ← Express app entry point
│   ├── package.json
│   └── .env.example          ← Copy to .env and fill in
│
└── frontend/                 ← React app
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── context/
    │   │   └── AppContext.js  ← Global state (user, page, results)
    │   ├── components/
    │   │   ├── Navbar.js
    │   │   └── Toast.js      ← Toast + ConfirmModal
    │   ├── pages/
    │   │   ├── AuthPage.js   ← Login + Register
    │   │   ├── AdminPage.js  ← Admin dashboard (4 tabs)
    │   │   ├── DoctorPage.js ← Doctor dashboard
    │   │   ├── UploadPage.js ← Retinal scan upload + ONNX inference
    │   │   ├── ResultsPage.js← Diagnosis results + save
    │   │   └── PatientPage.js← Patient history + AI Chat
    │   ├── utils/
    │   │   ├── api.js        ← All backend API calls
    │   │   └── constants.js  ← Stage names, colours, recommendations
    │   ├── App.js
    │   ├── index.js
    │   └── index.css         ← Full design system / global styles
    └── package.json
```

---

## 🛠 Software Requirements

| Software | Version | Download |
|----------|---------|----------|
| **Node.js** | ≥ 18.x | https://nodejs.org |
| **npm** | ≥ 9.x (comes with Node) | — |
| **Git** (optional) | any | https://git-scm.com |

> **Optional cloud services** (app works offline without them):
> - [Supabase](https://supabase.com) — Postgres database + Auth
> - [OpenRouter](https://openrouter.ai) — AI chat API

---

## 🚀 Quick Start

### Step 1 — Install Node.js
Download and install Node.js from https://nodejs.org (choose the LTS version).
Verify: `node -v` and `npm -v`

### Step 2 — Set up the Backend

```bash
# 1. Enter backend folder
cd drxai/backend

# 2. Install dependencies
npm install

# 3. Create your environment file
cp .env.example .env
# Then open .env in any text editor and fill in your keys (see below)

# 4. Start the server
npm run dev        # development (auto-restarts on changes)
# OR
npm start          # production
```

The backend will start at **http://localhost:5000**
Test it: http://localhost:5000/api/health

### Step 3 — Set up the Frontend

Open a **new terminal window**:

```bash
# 1. Enter frontend folder
cd drxai/frontend

# 2. Install dependencies
npm install

# 3. Create your environment file
cp .env.example .env
# The default (REACT_APP_API_URL=http://localhost:5000) works as-is

# 4. Start the React app
npm start
```

The frontend will open automatically at **http://localhost:3000**

---

## 🔑 Environment Variables

### Backend (`backend/.env`)

```env
# ── Supabase (optional) ──────────────────────────────────────────
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_KEY=eyJhbGci...   # service role key (bypass RLS)

# ── Admin ────────────────────────────────────────────────────────
ADMIN_EMAIL=admin@drxai.com
ADMIN_PASSWORD=Admin@12345

# ── OpenRouter AI Chat ────────────────────────────────────────────
OPENROUTER_API_KEY=sk-or-v1-...

# ── Server ───────────────────────────────────────────────────────
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
```

### Frontend (`frontend/.env`)

```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_SUPABASE_URL=https://your-project.supabase.co
REACT_APP_SUPABASE_ANON_KEY=eyJhbGci...
```

> **Running without Supabase?**
> Leave the Supabase fields empty or as placeholders. The app will run in
> **local mode** — users and exams are stored in the browser's localStorage.
> Admin credentials still work: `admin@drxai.com` / `Admin@12345`

---

## 🗄 Supabase Setup (Optional but Recommended)

1. Create a free project at https://supabase.com
2. Go to **SQL Editor** and run:

```sql
-- Profiles table
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  email text unique,
  role text check (role in ('admin','doctor','patient')),
  phone text,
  speciality text,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- Examinations table
create table examinations (
  id text primary key,
  doctor_id uuid references profiles(id),
  patient_id uuid references profiles(id),
  stage integer,
  confidence integer,
  probs text,
  notes text,
  medications text,
  image_data text,
  created_at timestamptz default now()
);

-- Allow authenticated users to read their own profile
alter table profiles enable row level security;
create policy "Users read own profile" on profiles for select using (auth.uid() = id);
create policy "Service role full access" on profiles using (true) with check (true);

alter table examinations enable row level security;
create policy "Service role full access exams" on examinations using (true) with check (true);
```

3. Go to **Project Settings → API** and copy:
   - **Project URL** → `SUPABASE_URL`
   - **anon public** key → `SUPABASE_ANON_KEY`
   - **service_role** key → `SUPABASE_SERVICE_KEY`

4. Go to **Authentication → Providers** and disable email confirmation for development.

---

## 🤖 AI Chat Setup (OpenRouter)

1. Create a free account at https://openrouter.ai
2. Go to **Keys** and create a new API key
3. Add it to `backend/.env` as `OPENROUTER_API_KEY`

Without this key, the chat uses built-in fallback responses about diabetic retinopathy.

---

## 👥 User Roles

| Role | Access |
|------|--------|
| **Admin** | All dashboards, register users, view all exams, manage users |
| **Doctor** | Own dashboard, upload & analyse scans, save exams, AI chat |
| **Patient** | Own examination history, AI chat |

Default admin: `admin@drxai.com` / `Admin@12345`

---

## 🧠 ONNX Model (AI Inference)

The app supports real ONNX model inference in the browser using ONNX Runtime Web.

To use a real DR classification model:
1. Export your PyTorch/TF model to ONNX format (input: `[1,3,224,224]`, output: `[1,5]` logits)
2. Place the file at `frontend/public/model/dr_model.onnx`
3. The app will auto-detect and use it

Without a model file, the app uses **simulated inference** for demo purposes.

---

## 📜 API Endpoints

```
POST   /api/auth/login           Login
POST   /api/auth/logout          Logout
GET    /api/auth/session         Validate session

GET    /api/users                List users (admin)
GET    /api/users/patients       List patients (doctor+)
POST   /api/users                Create user (admin)
DELETE /api/users/:id            Remove user (admin)

GET    /api/examinations         List exams (role-filtered)
GET    /api/examinations/:id     Get single exam
POST   /api/examinations         Save exam
DELETE /api/examinations/:id     Delete exam
GET    /api/examinations/stats/summary  Admin stats

POST   /api/chat                 AI chat proxy

GET    /api/health               Health check
```

---

## 🔧 Troubleshooting

**"Module not found" errors**
```bash
# Make sure you're in the right folder and ran npm install
cd backend && npm install
cd ../frontend && npm install
```

**Port already in use**
```bash
# Change PORT in backend/.env, e.g. PORT=5001
# Then update frontend/.env: REACT_APP_API_URL=http://localhost:5001
```

**CORS errors in browser**
- Make sure `FRONTEND_URL=http://localhost:3000` is set in `backend/.env`
- Restart the backend after changing `.env`

**Supabase "Email confirmation required"**
- Go to Supabase → Authentication → Providers → Email → disable "Confirm email"

---

## 🏗 Building for Production

```bash
# Backend — just run with NODE_ENV=production
cd backend
NODE_ENV=production npm start

# Frontend — build static files
cd frontend
npm run build
# Serve the build/ folder with any static host (Vercel, Netlify, Nginx, etc.)
```
